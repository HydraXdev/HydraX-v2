# MONITOR LOG AND SEND TELEGRAM ALERT
import time, json
from bitten_core.mission_briefing_generator_v5 import generate_mission
from telegram import Bot

bot = Bot(token="YOUR_BOT_TOKEN")

def monitor_apex_logs():
    seen = set()
    with open("/root/HydraX-v2/apex_v5_live_real.log") as f:
        while True:
            line = f.readline()
            if not line:
                time.sleep(1)
                continue
            if "🎯 SIGNAL" in line and line not in seen:
                seen.add(line)
                parts = line.split()
                symbol = parts[3]
                direction = parts[4]
                tcs = int(parts[-1].replace('%', ''))
                signal = {
                    "symbol": symbol,
                    "type": direction.lower(),
                    "tp": 2382.0,
                    "sl": 2370.0,
                    "tcs_score": tcs
                }
                user_id = "7176191872"
                mission = generate_mission(signal, user_id)
                url = f"https://joinbitten.com/hud?mission_id={mission['mission_id']}"
                msg = f"🪖 {symbol.upper()} Mission
TCS: {tcs}%
[🎯 VIEW INTEL]({url})"
                bot.send_message(chat_id=user_id, text=msg, parse_mode="Markdown")
