# SEND TO BRIDGE SOCKET
import socket, json

def execute_trade(mission):
    payload = {
        "symbol": mission["symbol"],
        "type": mission["type"],
        "lot": mission["lot_size"],
        "tp": mission["tp"],
        "sl": mission["sl"],
        "comment": mission["mission_id"]
    }
    sock = socket.socket()
    sock.connect(("127.0.0.1", 9000))
    sock.send(json.dumps(payload).encode())
    sock.close()
    return "sent_to_bridge"
