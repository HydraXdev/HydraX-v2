# GENERATE MISSION OBJECT
from datetime import datetime, timedelta
import json, os, time

MISSION_DIR = "./missions/"

def generate_mission(signal, user_id):
    expiry_minutes = 5
    mission = {
        "mission_id": f"{user_id}_{int(time.time())}",
        "user_id": user_id,
        "symbol": signal["symbol"],
        "type": signal["type"],
        "tp": signal["tp"],
        "sl": signal["sl"],
        "tcs": signal["tcs_score"],
        "risk": 1.5,
        "account_balance": 2913.25,
        "lot_size": 0.12,
        "timestamp": datetime.utcnow().isoformat(),
        "expires_at": (datetime.utcnow() + timedelta(minutes=expiry_minutes)).isoformat(),
        "status": "pending"
    }
    os.makedirs(MISSION_DIR, exist_ok=True)
    with open(f"{MISSION_DIR}{mission['mission_id']}.json", "w") as f:
        json.dump(mission, f)
    return mission
