# MISSION DISPLAY + FIRE API
from flask import Flask, request
from datetime import datetime
import json, os

app = Flask(__name__)

@app.route("/api/mission-status/<mission_id>")
def mission_status(mission_id):
    try:
        with open(f"./missions/{mission_id}.json") as f:
            mission = json.load(f)
        expires = datetime.fromisoformat(mission["expires_at"])
        mission["time_remaining"] = max(0, int((expires - datetime.utcnow()).total_seconds()))
        return mission
    except:
        return {"status": "error", "reason": "not found"}, 404

@app.route("/api/fire", methods=["POST"])
def handle_fire():
    mission = request.json
    mission_id = mission.get("mission_id")
    try:
        with open(f"./missions/{mission_id}.json") as f:
            mission_data = json.load(f)
        if datetime.utcnow() > datetime.fromisoformat(mission_data["expires_at"]):
            return {"status": "expired"}, 403
        mission_data["status"] = "fired"
        with open(f"./missions/{mission_id}.json", "w") as f:
            json.dump(mission_data, f)
        from fire_router import execute_trade
        result = execute_trade(mission_data)
        return {"status": "success", "result": result}
    except Exception as e:
        return {"status": "fail", "error": str(e)}
