# persona_engine.py

def assign_persona(user_profile):
    traits = user_profile.get("traits", [])
    if "aggressive" in traits:
        return "Brute"
    elif "observer" in traits:
        return "Phantom"
    elif "analytical" in traits:
        return "Scholar"
    elif "discipline" in traits:
        return "Warden"
    else:
        return "Default"
