# persona_hooks.py

def adjust_signal_by_persona(signal, persona):
    if persona == "Scholar" and signal["duration"] < 30:
        signal["priority_score"] -= 10
    elif persona == "Brute" and signal["risk"] < 1.5:
        signal["priority_score"] -= 20
    elif persona == "Phantom":
        signal["stealth_only"] = True
    return signal

def whisper_message_by_persona(event_type, persona):
    responses = {
        "Brute": {
            "win": "You crushed that fire. Zero hesitation.",
            "loss": "Pull it back. Discipline over emotion."
        },
        "Scholar": {
            "win": "Precision logged. A lesson in patience.",
            "loss": "Log the data. Every loss teaches."
        },
        "Phantom": {
            "win": "Quiet execution. Bit noticed.",
            "loss": "Silence returned. Review the ghostprint."
        }
    }
    return responses.get(persona, {}).get(event_type, "Event noted.")
