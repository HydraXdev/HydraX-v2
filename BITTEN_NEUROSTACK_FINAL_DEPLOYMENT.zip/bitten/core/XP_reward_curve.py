# XP_reward_curve.py

# Adjusts XP based on user tier, persona, risk patterns, and streaks