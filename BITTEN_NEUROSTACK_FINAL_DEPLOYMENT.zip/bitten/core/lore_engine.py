# lore_engine.py

# Delivers adaptive lore fragments based on user persona and trigger events