# BITTEN FULL PROJECT SPEC

(Contents auto-filled by assistant recovery system.)
