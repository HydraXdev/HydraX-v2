# BITTEN TACTICAL APPENDIX

(Contents auto-filled by assistant recovery system.)
