# OPERATION EDUCATION: WebApp Layer Spec

## MODULES

- Tactical Brief Panel
- Rank Display + XP Bar
- Stealth + MedicBot UI Modals
- MORE INFO Glossary System

... (truncated for brevity)
