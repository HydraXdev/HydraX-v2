# Ghost Feed Module (stub)
# Streams MT5 terminal prices (bid, ask, OHLCV)
# Feeds TOC scoring engine through socket or API
