# Special Shot Protocol

## Trade Types:
- Hammer: TCS ≥ 94, RR ≥ 3.5, all confluences
- Shadow Strike: TCS 84–93, RR ≥ 2.0
- Classified: XP/manual only, elite-triggered

Used to override normal logic and push global/special alerts.
