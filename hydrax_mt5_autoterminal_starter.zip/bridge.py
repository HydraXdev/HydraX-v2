import socket, json

PORT = 9013
FIRE_FILE = "./MQL5/Files/fire.txt"

s = socket.socket()
s.bind(("0.0.0.0", PORT))
s.listen(1)
print(f"Bridge ready on port {PORT}")

while True:
    conn, addr = s.accept()
    data = conn.recv(2048)
    payload = json.loads(data.decode())
    with open(FIRE_FILE, "w") as f:
        json.dump(payload, f)
    conn.send(b"FIRE_RECEIVED")
    conn.close()
