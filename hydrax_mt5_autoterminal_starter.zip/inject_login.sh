#!/bin/bash
echo -e "[Login]\nLogin=$1\nPassword=$2\nServer=$3" > ./config/login.ini
