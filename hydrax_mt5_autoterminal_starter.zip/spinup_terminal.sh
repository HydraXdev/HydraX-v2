#!/bin/bash

while [[ "$#" -gt 0 ]]; do
    case $1 in
        --login) LOGIN="$2"; shift ;;
        --pass) PASS="$2"; shift ;;
        --server) SERVER="$2"; shift ;;
        --port) PORT="$2"; shift ;;
        --label) LABEL="$2"; shift ;;
    esac
    shift
done

mkdir -p ./config
echo -e "[Login]\nLogin=${LOGIN}\nPassword=${PASS}\nServer=${SERVER}" > ./config/login.ini

echo "Launching terminal for $LABEL on port $PORT with login $LOGIN"
docker run -d --name $LABEL -v $(pwd)/MQL5:/home/wine/.wine/drive_c/MT5/MQL5            -v $(pwd)/config:/home/wine/.wine/drive_c/MT5/config            -p $PORT:$PORT hydrax-mt5
