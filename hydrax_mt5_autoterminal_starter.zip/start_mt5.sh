#!/bin/bash
xvfb-run --auto-servernum wine terminal.exe /config:config/terminal.ini
